﻿namespace vbtournamentreporter
{
    partial class reporter
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource106 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource107 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource108 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource109 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource110 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource111 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource112 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource113 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource114 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource115 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource116 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource117 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource118 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource119 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource120 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource121 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource122 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource123 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource124 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource125 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource126 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource127 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource128 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageVS = new System.Windows.Forms.TabPage();
            this.reportViewerVS = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPageVR = new System.Windows.Forms.TabPage();
            this.reportViewerVR = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPageZS = new System.Windows.Forms.TabPage();
            this.reportViewerZS = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPageZR = new System.Windows.Forms.TabPage();
            this.reportViewerZR = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPageKS = new System.Windows.Forms.TabPage();
            this.reportViewerKS = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPagePS = new System.Windows.Forms.TabPage();
            this.reportViewerPS = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPagePR = new System.Windows.Forms.TabPage();
            this.reportViewerPR = new Microsoft.Reporting.WinForms.ReportViewer();
            this.vorrunde_spielplanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tables = new vbtournamentreporter.tables();
            this.vorrunde_gra_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grb_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grc_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grd_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_gre_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grf_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grg_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grh_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_gri_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_spielplanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_gra_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grb_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grc_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grd_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_gre_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grf_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grg_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grh_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_gri_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kreuzspiele_spielplanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.platzspiele_spielplanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.platzierungen_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_spielplanTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_spielplanTableAdapter();
            this.zwischenrunde_spielplanTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_spielplanTableAdapter();
            this.kreuzspiele_spielplanTableAdapter = new vbtournamentreporter.tablesTableAdapters.kreuzspiele_spielplanTableAdapter();
            this.platzspiele_spielplanTableAdapter = new vbtournamentreporter.tablesTableAdapters.platzspiele_spielplanTableAdapter();
            this.platzierungen_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.platzierungen_viewTableAdapter();
            this.vorrunde_gra_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_gra_viewTableAdapter();
            this.vorrunde_grb_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grb_viewTableAdapter();
            this.vorrunde_grc_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grc_viewTableAdapter();
            this.vorrunde_grd_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grd_viewTableAdapter();
            this.vorrunde_gre_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_gre_viewTableAdapter();
            this.vorrunde_grf_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grf_viewTableAdapter();
            this.vorrunde_grg_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grg_viewTableAdapter();
            this.vorrunde_grh_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grh_viewTableAdapter();
            this.vorrunde_gri_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_gri_viewTableAdapter();
            this.zwischenrunde_gra_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_gra_viewTableAdapter();
            this.zwischenrunde_grb_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grb_viewTableAdapter();
            this.zwischenrunde_grc_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grc_viewTableAdapter();
            this.zwischenrunde_grd_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grd_viewTableAdapter();
            this.zwischenrunde_gre_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_gre_viewTableAdapter();
            this.zwischenrunde_grf_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grf_viewTableAdapter();
            this.zwischenrunde_grg_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grg_viewTableAdapter();
            this.zwischenrunde_grh_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grh_viewTableAdapter();
            this.zwischenrunde_gri_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_gri_viewTableAdapter();
            this.tabControlMain.SuspendLayout();
            this.tabPageVS.SuspendLayout();
            this.tabPageVR.SuspendLayout();
            this.tabPageZS.SuspendLayout();
            this.tabPageZR.SuspendLayout();
            this.tabPageKS.SuspendLayout();
            this.tabPagePS.SuspendLayout();
            this.tabPagePR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_spielplanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tables)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gra_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grb_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grc_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grd_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gre_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grf_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grg_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grh_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gri_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_spielplanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gra_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grb_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grc_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grd_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gre_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grf_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grg_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grh_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gri_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kreuzspiele_spielplanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.platzspiele_spielplanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.platzierungen_viewBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageVS);
            this.tabControlMain.Controls.Add(this.tabPageVR);
            this.tabControlMain.Controls.Add(this.tabPageZS);
            this.tabControlMain.Controls.Add(this.tabPageZR);
            this.tabControlMain.Controls.Add(this.tabPageKS);
            this.tabControlMain.Controls.Add(this.tabPagePS);
            this.tabControlMain.Controls.Add(this.tabPagePR);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Location = new System.Drawing.Point(0, 0);
            this.tabControlMain.Margin = new System.Windows.Forms.Padding(4);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(1043, 284);
            this.tabControlMain.TabIndex = 8;
            // 
            // tabPageVS
            // 
            this.tabPageVS.Controls.Add(this.reportViewerVS);
            this.tabPageVS.Location = new System.Drawing.Point(4, 25);
            this.tabPageVS.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageVS.Name = "tabPageVS";
            this.tabPageVS.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageVS.Size = new System.Drawing.Size(1035, 255);
            this.tabPageVS.TabIndex = 0;
            this.tabPageVS.Text = "Vorrunde Spielplan";
            this.tabPageVS.UseVisualStyleBackColor = true;
            // 
            // reportViewerVS
            // 
            this.reportViewerVS.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource106.Name = "vorrunde_spielplan";
            reportDataSource106.Value = this.vorrunde_spielplanBindingSource;
            this.reportViewerVS.LocalReport.DataSources.Add(reportDataSource106);
            this.reportViewerVS.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_vorrunde_spielplan.rdlc";
            this.reportViewerVS.Location = new System.Drawing.Point(4, 4);
            this.reportViewerVS.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewerVS.Name = "reportViewerVS";
            this.reportViewerVS.Size = new System.Drawing.Size(1027, 247);
            this.reportViewerVS.TabIndex = 0;
            // 
            // tabPageVR
            // 
            this.tabPageVR.Controls.Add(this.reportViewerVR);
            this.tabPageVR.Location = new System.Drawing.Point(4, 25);
            this.tabPageVR.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageVR.Name = "tabPageVR";
            this.tabPageVR.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageVR.Size = new System.Drawing.Size(1035, 255);
            this.tabPageVR.TabIndex = 1;
            this.tabPageVR.Text = "Vorrunde Ergebnisse";
            this.tabPageVR.UseVisualStyleBackColor = true;
            // 
            // reportViewerVR
            // 
            this.reportViewerVR.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource107.Name = "vorrunde_gruppe_a";
            reportDataSource107.Value = this.vorrunde_gra_viewBindingSource;
            reportDataSource108.Name = "vorrunde_gruppe_b";
            reportDataSource108.Value = this.vorrunde_grb_viewBindingSource;
            reportDataSource109.Name = "vorrunde_gruppe_c";
            reportDataSource109.Value = this.vorrunde_grc_viewBindingSource;
            reportDataSource110.Name = "vorrunde_gruppe_d";
            reportDataSource110.Value = this.vorrunde_grd_viewBindingSource;
            reportDataSource111.Name = "vorrunde_gruppe_e";
            reportDataSource111.Value = this.vorrunde_gre_viewBindingSource;
            reportDataSource112.Name = "vorrunde_gruppe_f";
            reportDataSource112.Value = this.vorrunde_grf_viewBindingSource;
            reportDataSource113.Name = "vorrunde_gruppe_g";
            reportDataSource113.Value = this.vorrunde_grg_viewBindingSource;
            reportDataSource114.Name = "vorrunde_gruppe_h";
            reportDataSource114.Value = this.vorrunde_grh_viewBindingSource;
            reportDataSource127.Name = "vorrunde_gruppe_i";
            reportDataSource127.Value = this.vorrunde_gri_viewBindingSource;
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource107);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource108);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource109);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource110);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource111);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource112);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource113);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource114);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource127);
            this.reportViewerVR.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_vorrunde.rdlc";
            this.reportViewerVR.Location = new System.Drawing.Point(4, 4);
            this.reportViewerVR.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewerVR.Name = "reportViewerVR";
            this.reportViewerVR.Size = new System.Drawing.Size(1027, 247);
            this.reportViewerVR.TabIndex = 0;
            // 
            // tabPageZS
            // 
            this.tabPageZS.Controls.Add(this.reportViewerZS);
            this.tabPageZS.Location = new System.Drawing.Point(4, 25);
            this.tabPageZS.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageZS.Name = "tabPageZS";
            this.tabPageZS.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageZS.Size = new System.Drawing.Size(1035, 255);
            this.tabPageZS.TabIndex = 2;
            this.tabPageZS.Text = "Zwischenrunde Spielplan";
            this.tabPageZS.UseVisualStyleBackColor = true;
            // 
            // reportViewerZS
            // 
            this.reportViewerZS.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource115.Name = "zwischenrunde_spielplan";
            reportDataSource115.Value = this.zwischenrunde_spielplanBindingSource;
            this.reportViewerZS.LocalReport.DataSources.Add(reportDataSource115);
            this.reportViewerZS.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_zwischenrunde_spielplan.rdlc";
            this.reportViewerZS.Location = new System.Drawing.Point(4, 4);
            this.reportViewerZS.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewerZS.Name = "reportViewerZS";
            this.reportViewerZS.Size = new System.Drawing.Size(1027, 247);
            this.reportViewerZS.TabIndex = 0;
            // 
            // tabPageZR
            // 
            this.tabPageZR.Controls.Add(this.reportViewerZR);
            this.tabPageZR.Location = new System.Drawing.Point(4, 25);
            this.tabPageZR.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageZR.Name = "tabPageZR";
            this.tabPageZR.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageZR.Size = new System.Drawing.Size(1035, 255);
            this.tabPageZR.TabIndex = 3;
            this.tabPageZR.Text = "Zwischenrunde Ergebnisse";
            this.tabPageZR.UseVisualStyleBackColor = true;
            // 
            // reportViewerZR
            // 
            this.reportViewerZR.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource116.Name = "zwischenrunde_gruppe_a";
            reportDataSource116.Value = this.zwischenrunde_gra_viewBindingSource;
            reportDataSource117.Name = "zwischenrunde_gruppe_b";
            reportDataSource117.Value = this.zwischenrunde_grb_viewBindingSource;
            reportDataSource118.Name = "zwischenrunde_gruppe_c";
            reportDataSource118.Value = this.zwischenrunde_grc_viewBindingSource;
            reportDataSource119.Name = "zwischenrunde_gruppe_d";
            reportDataSource119.Value = this.zwischenrunde_grd_viewBindingSource;
            reportDataSource120.Name = "zwischenrunde_gruppe_e";
            reportDataSource120.Value = this.zwischenrunde_gre_viewBindingSource;
            reportDataSource121.Name = "zwischenrunde_gruppe_f";
            reportDataSource121.Value = this.zwischenrunde_grf_viewBindingSource;
            reportDataSource122.Name = "zwischenrunde_gruppe_g";
            reportDataSource122.Value = this.zwischenrunde_grg_viewBindingSource;
            reportDataSource123.Name = "zwischenrunde_gruppe_h";
            reportDataSource123.Value = this.zwischenrunde_grh_viewBindingSource;
            reportDataSource128.Name = "zwischenrunde_gruppe_i";
            reportDataSource128.Value = this.zwischenrunde_gri_viewBindingSource;
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource116);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource117);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource118);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource119);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource120);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource121);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource122);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource123);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource128);
            this.reportViewerZR.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_zwischenrunde.rdlc";
            this.reportViewerZR.Location = new System.Drawing.Point(4, 4);
            this.reportViewerZR.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewerZR.Name = "reportViewerZR";
            this.reportViewerZR.Size = new System.Drawing.Size(1027, 247);
            this.reportViewerZR.TabIndex = 0;
            // 
            // tabPageKS
            // 
            this.tabPageKS.Controls.Add(this.reportViewerKS);
            this.tabPageKS.Location = new System.Drawing.Point(4, 25);
            this.tabPageKS.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageKS.Name = "tabPageKS";
            this.tabPageKS.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageKS.Size = new System.Drawing.Size(1035, 255);
            this.tabPageKS.TabIndex = 4;
            this.tabPageKS.Text = "Kreuzspiele Spielplan";
            this.tabPageKS.UseVisualStyleBackColor = true;
            // 
            // reportViewerKS
            // 
            this.reportViewerKS.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource124.Name = "kreuzspiele_spielplan";
            reportDataSource124.Value = this.kreuzspiele_spielplanBindingSource;
            this.reportViewerKS.LocalReport.DataSources.Add(reportDataSource124);
            this.reportViewerKS.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_kreuzspiele_spielplan.rdlc";
            this.reportViewerKS.Location = new System.Drawing.Point(4, 4);
            this.reportViewerKS.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewerKS.Name = "reportViewerKS";
            this.reportViewerKS.Size = new System.Drawing.Size(1027, 247);
            this.reportViewerKS.TabIndex = 0;
            // 
            // tabPagePS
            // 
            this.tabPagePS.Controls.Add(this.reportViewerPS);
            this.tabPagePS.Location = new System.Drawing.Point(4, 25);
            this.tabPagePS.Margin = new System.Windows.Forms.Padding(4);
            this.tabPagePS.Name = "tabPagePS";
            this.tabPagePS.Padding = new System.Windows.Forms.Padding(4);
            this.tabPagePS.Size = new System.Drawing.Size(1035, 255);
            this.tabPagePS.TabIndex = 5;
            this.tabPagePS.Text = "Platzspiele Spielplan";
            this.tabPagePS.UseVisualStyleBackColor = true;
            // 
            // reportViewerPS
            // 
            this.reportViewerPS.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource125.Name = "platzspiele_spielplan";
            reportDataSource125.Value = this.platzspiele_spielplanBindingSource;
            this.reportViewerPS.LocalReport.DataSources.Add(reportDataSource125);
            this.reportViewerPS.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_platzspiele_spielplan.rdlc";
            this.reportViewerPS.Location = new System.Drawing.Point(4, 4);
            this.reportViewerPS.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewerPS.Name = "reportViewerPS";
            this.reportViewerPS.Size = new System.Drawing.Size(1027, 247);
            this.reportViewerPS.TabIndex = 0;
            // 
            // tabPagePR
            // 
            this.tabPagePR.Controls.Add(this.reportViewerPR);
            this.tabPagePR.Location = new System.Drawing.Point(4, 25);
            this.tabPagePR.Margin = new System.Windows.Forms.Padding(4);
            this.tabPagePR.Name = "tabPagePR";
            this.tabPagePR.Padding = new System.Windows.Forms.Padding(4);
            this.tabPagePR.Size = new System.Drawing.Size(1035, 255);
            this.tabPagePR.TabIndex = 6;
            this.tabPagePR.Text = "Platzierungen";
            this.tabPagePR.UseVisualStyleBackColor = true;
            // 
            // reportViewerPR
            // 
            this.reportViewerPR.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource126.Name = "platzierungen_view";
            reportDataSource126.Value = this.platzierungen_viewBindingSource;
            this.reportViewerPR.LocalReport.DataSources.Add(reportDataSource126);
            this.reportViewerPR.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_platzierung.rdlc";
            this.reportViewerPR.Location = new System.Drawing.Point(4, 4);
            this.reportViewerPR.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewerPR.Name = "reportViewerPR";
            this.reportViewerPR.Size = new System.Drawing.Size(1027, 247);
            this.reportViewerPR.TabIndex = 0;
            // 
            // vorrunde_spielplanBindingSource
            // 
            this.vorrunde_spielplanBindingSource.DataMember = "vorrunde_spielplan";
            this.vorrunde_spielplanBindingSource.DataSource = this.tables;
            // 
            // tables
            // 
            this.tables.DataSetName = "tables";
            this.tables.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vorrunde_gra_viewBindingSource
            // 
            this.vorrunde_gra_viewBindingSource.DataMember = "vorrunde_gra_view";
            this.vorrunde_gra_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grb_viewBindingSource
            // 
            this.vorrunde_grb_viewBindingSource.DataMember = "vorrunde_grb_view";
            this.vorrunde_grb_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grc_viewBindingSource
            // 
            this.vorrunde_grc_viewBindingSource.DataMember = "vorrunde_grc_view";
            this.vorrunde_grc_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grd_viewBindingSource
            // 
            this.vorrunde_grd_viewBindingSource.DataMember = "vorrunde_grd_view";
            this.vorrunde_grd_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_gre_viewBindingSource
            // 
            this.vorrunde_gre_viewBindingSource.DataMember = "vorrunde_gre_view";
            this.vorrunde_gre_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grf_viewBindingSource
            // 
            this.vorrunde_grf_viewBindingSource.DataMember = "vorrunde_grf_view";
            this.vorrunde_grf_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grg_viewBindingSource
            // 
            this.vorrunde_grg_viewBindingSource.DataMember = "vorrunde_grg_view";
            this.vorrunde_grg_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grh_viewBindingSource
            // 
            this.vorrunde_grh_viewBindingSource.DataMember = "vorrunde_grh_view";
            this.vorrunde_grh_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_gri_viewBindingSource
            // 
            this.vorrunde_gri_viewBindingSource.DataMember = "vorrunde_gri_view";
            this.vorrunde_gri_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_spielplanBindingSource
            // 
            this.zwischenrunde_spielplanBindingSource.DataMember = "zwischenrunde_spielplan";
            this.zwischenrunde_spielplanBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_gra_viewBindingSource
            // 
            this.zwischenrunde_gra_viewBindingSource.DataMember = "zwischenrunde_gra_view";
            this.zwischenrunde_gra_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grb_viewBindingSource
            // 
            this.zwischenrunde_grb_viewBindingSource.DataMember = "zwischenrunde_grb_view";
            this.zwischenrunde_grb_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grc_viewBindingSource
            // 
            this.zwischenrunde_grc_viewBindingSource.DataMember = "zwischenrunde_grc_view";
            this.zwischenrunde_grc_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grd_viewBindingSource
            // 
            this.zwischenrunde_grd_viewBindingSource.DataMember = "zwischenrunde_grd_view";
            this.zwischenrunde_grd_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_gre_viewBindingSource
            // 
            this.zwischenrunde_gre_viewBindingSource.DataMember = "zwischenrunde_gre_view";
            this.zwischenrunde_gre_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grf_viewBindingSource
            // 
            this.zwischenrunde_grf_viewBindingSource.DataMember = "zwischenrunde_grf_view";
            this.zwischenrunde_grf_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grg_viewBindingSource
            // 
            this.zwischenrunde_grg_viewBindingSource.DataMember = "zwischenrunde_grg_view";
            this.zwischenrunde_grg_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grh_viewBindingSource
            // 
            this.zwischenrunde_grh_viewBindingSource.DataMember = "zwischenrunde_grh_view";
            this.zwischenrunde_grh_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_gri_viewBindingSource
            // 
            this.zwischenrunde_gri_viewBindingSource.DataMember = "zwischenrunde_gri_view";
            this.zwischenrunde_gri_viewBindingSource.DataSource = this.tables;
            // 
            // kreuzspiele_spielplanBindingSource
            // 
            this.kreuzspiele_spielplanBindingSource.DataMember = "kreuzspiele_spielplan";
            this.kreuzspiele_spielplanBindingSource.DataSource = this.tables;
            // 
            // platzspiele_spielplanBindingSource
            // 
            this.platzspiele_spielplanBindingSource.DataMember = "platzspiele_spielplan";
            this.platzspiele_spielplanBindingSource.DataSource = this.tables;
            // 
            // platzierungen_viewBindingSource
            // 
            this.platzierungen_viewBindingSource.DataMember = "platzierungen_view";
            this.platzierungen_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_spielplanTableAdapter
            // 
            this.vorrunde_spielplanTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_spielplanTableAdapter
            // 
            this.zwischenrunde_spielplanTableAdapter.ClearBeforeFill = true;
            // 
            // kreuzspiele_spielplanTableAdapter
            // 
            this.kreuzspiele_spielplanTableAdapter.ClearBeforeFill = true;
            // 
            // platzspiele_spielplanTableAdapter
            // 
            this.platzspiele_spielplanTableAdapter.ClearBeforeFill = true;
            // 
            // platzierungen_viewTableAdapter
            // 
            this.platzierungen_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_gra_viewTableAdapter
            // 
            this.vorrunde_gra_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grb_viewTableAdapter
            // 
            this.vorrunde_grb_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grc_viewTableAdapter
            // 
            this.vorrunde_grc_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grd_viewTableAdapter
            // 
            this.vorrunde_grd_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_gre_viewTableAdapter
            // 
            this.vorrunde_gre_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grf_viewTableAdapter
            // 
            this.vorrunde_grf_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grg_viewTableAdapter
            // 
            this.vorrunde_grg_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grh_viewTableAdapter
            // 
            this.vorrunde_grh_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_gri_viewTableAdapter
            // 
            this.vorrunde_gri_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_gra_viewTableAdapter
            // 
            this.zwischenrunde_gra_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grb_viewTableAdapter
            // 
            this.zwischenrunde_grb_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grc_viewTableAdapter
            // 
            this.zwischenrunde_grc_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grd_viewTableAdapter
            // 
            this.zwischenrunde_grd_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_gre_viewTableAdapter
            // 
            this.zwischenrunde_gre_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grf_viewTableAdapter
            // 
            this.zwischenrunde_grf_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grg_viewTableAdapter
            // 
            this.zwischenrunde_grg_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grh_viewTableAdapter
            // 
            this.zwischenrunde_grh_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_gri_viewTableAdapter
            // 
            this.zwischenrunde_gri_viewTableAdapter.ClearBeforeFill = true;
            // 
            // reporter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 284);
            this.Controls.Add(this.tabControlMain);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "reporter";
            this.Text = "Reporter";
            this.Load += new System.EventHandler(this.reporter_Load);
            this.tabControlMain.ResumeLayout(false);
            this.tabPageVS.ResumeLayout(false);
            this.tabPageVR.ResumeLayout(false);
            this.tabPageZS.ResumeLayout(false);
            this.tabPageZR.ResumeLayout(false);
            this.tabPageKS.ResumeLayout(false);
            this.tabPagePS.ResumeLayout(false);
            this.tabPagePR.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_spielplanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tables)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gra_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grb_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grc_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grd_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gre_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grf_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grg_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grh_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gri_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_spielplanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gra_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grb_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grc_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grd_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gre_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grf_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grg_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grh_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gri_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kreuzspiele_spielplanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.platzspiele_spielplanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.platzierungen_viewBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion


        private System.Windows.Forms.BindingSource vorrunde_spielplanBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_spielplanBindingSource;
        private System.Windows.Forms.BindingSource kreuzspiele_spielplanBindingSource;
        private System.Windows.Forms.BindingSource platzspiele_spielplanBindingSource;
        private System.Windows.Forms.BindingSource platzierungen_viewBindingSource;

        private tables tables;
        private tablesTableAdapters.vorrunde_spielplanTableAdapter vorrunde_spielplanTableAdapter;
        private tablesTableAdapters.zwischenrunde_spielplanTableAdapter zwischenrunde_spielplanTableAdapter;
        private tablesTableAdapters.kreuzspiele_spielplanTableAdapter kreuzspiele_spielplanTableAdapter;
        private tablesTableAdapters.platzspiele_spielplanTableAdapter platzspiele_spielplanTableAdapter;
        private tablesTableAdapters.platzierungen_viewTableAdapter platzierungen_viewTableAdapter;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageVS;
        private System.Windows.Forms.TabPage tabPageVR;
        private System.Windows.Forms.TabPage tabPageZS;
        private System.Windows.Forms.TabPage tabPageZR;
        private System.Windows.Forms.TabPage tabPageKS;
        private System.Windows.Forms.TabPage tabPagePS;
        private System.Windows.Forms.TabPage tabPagePR;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerVS;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerVR;
        private System.Windows.Forms.BindingSource vorrunde_gra_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grb_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grc_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grd_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_gre_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grf_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grg_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grh_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_gri_viewBindingSource;
        private tablesTableAdapters.vorrunde_gra_viewTableAdapter vorrunde_gra_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grb_viewTableAdapter vorrunde_grb_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grc_viewTableAdapter vorrunde_grc_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grd_viewTableAdapter vorrunde_grd_viewTableAdapter;
        private tablesTableAdapters.vorrunde_gre_viewTableAdapter vorrunde_gre_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grf_viewTableAdapter vorrunde_grf_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grg_viewTableAdapter vorrunde_grg_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grh_viewTableAdapter vorrunde_grh_viewTableAdapter;
        private tablesTableAdapters.vorrunde_gri_viewTableAdapter vorrunde_gri_viewTableAdapter;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerZS;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerZR;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerKS;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerPS;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerPR;
        private System.Windows.Forms.BindingSource zwischenrunde_gra_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grb_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grc_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grd_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_gre_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grf_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grg_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grh_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_gri_viewBindingSource;
        private tablesTableAdapters.zwischenrunde_gra_viewTableAdapter zwischenrunde_gra_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grb_viewTableAdapter zwischenrunde_grb_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grc_viewTableAdapter zwischenrunde_grc_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grd_viewTableAdapter zwischenrunde_grd_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_gre_viewTableAdapter zwischenrunde_gre_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grf_viewTableAdapter zwischenrunde_grf_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grg_viewTableAdapter zwischenrunde_grg_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grh_viewTableAdapter zwischenrunde_grh_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_gri_viewTableAdapter zwischenrunde_gri_viewTableAdapter;
    }
}

