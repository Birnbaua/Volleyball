﻿namespace vbtournamentreporter
{


    partial class tables
    {
    }
}