﻿namespace vbtournamentreporter
{
    partial class reporter
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource4 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource5 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource6 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource7 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource8 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource9 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource10 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource11 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource12 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource13 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource14 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource15 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource16 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource17 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource18 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource19 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource20 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource21 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.vorrunde_spielplanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tables = new vbtournamentreporter.tables();
            this.vorrunde_gra_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grb_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grc_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grd_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_gre_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grf_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grg_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_grh_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_spielplanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kreuzspiele_spielplanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.platzspiele_spielplanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.platzierungen_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vorrunde_spielplanTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_spielplanTableAdapter();
            this.zwischenrunde_spielplanTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_spielplanTableAdapter();
            this.kreuzspiele_spielplanTableAdapter = new vbtournamentreporter.tablesTableAdapters.kreuzspiele_spielplanTableAdapter();
            this.platzspiele_spielplanTableAdapter = new vbtournamentreporter.tablesTableAdapters.platzspiele_spielplanTableAdapter();
            this.platzierungen_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.platzierungen_viewTableAdapter();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageVS = new System.Windows.Forms.TabPage();
            this.reportViewerVS = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPageVR = new System.Windows.Forms.TabPage();
            this.reportViewerVR = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPageZS = new System.Windows.Forms.TabPage();
            this.reportViewerZS = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPageZR = new System.Windows.Forms.TabPage();
            this.reportViewerZR = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPageKS = new System.Windows.Forms.TabPage();
            this.reportViewerKS = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPagePS = new System.Windows.Forms.TabPage();
            this.reportViewerPS = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tabPagePR = new System.Windows.Forms.TabPage();
            this.reportViewerPR = new Microsoft.Reporting.WinForms.ReportViewer();
            this.vorrunde_gra_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_gra_viewTableAdapter();
            this.vorrunde_grb_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grb_viewTableAdapter();
            this.vorrunde_grc_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grc_viewTableAdapter();
            this.vorrunde_grd_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grd_viewTableAdapter();
            this.vorrunde_gre_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_gre_viewTableAdapter();
            this.vorrunde_grf_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grf_viewTableAdapter();
            this.vorrunde_grg_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grg_viewTableAdapter();
            this.vorrunde_grh_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.vorrunde_grh_viewTableAdapter();
            this.zwischenrunde_gra_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_gra_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_gra_viewTableAdapter();
            this.zwischenrunde_grb_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grb_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grb_viewTableAdapter();
            this.zwischenrunde_grc_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grc_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grc_viewTableAdapter();
            this.zwischenrunde_grd_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grd_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grd_viewTableAdapter();
            this.zwischenrunde_gre_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_gre_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_gre_viewTableAdapter();
            this.zwischenrunde_grf_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grf_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grf_viewTableAdapter();
            this.zwischenrunde_grg_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grg_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grg_viewTableAdapter();
            this.zwischenrunde_grh_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zwischenrunde_grh_viewTableAdapter = new vbtournamentreporter.tablesTableAdapters.zwischenrunde_grh_viewTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_spielplanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tables)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gra_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grb_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grc_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grd_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gre_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grf_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grg_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grh_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_spielplanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kreuzspiele_spielplanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.platzspiele_spielplanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.platzierungen_viewBindingSource)).BeginInit();
            this.tabControlMain.SuspendLayout();
            this.tabPageVS.SuspendLayout();
            this.tabPageVR.SuspendLayout();
            this.tabPageZS.SuspendLayout();
            this.tabPageZR.SuspendLayout();
            this.tabPageKS.SuspendLayout();
            this.tabPagePS.SuspendLayout();
            this.tabPagePR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gra_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grb_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grc_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grd_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gre_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grf_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grg_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grh_viewBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // vorrunde_spielplanBindingSource
            // 
            this.vorrunde_spielplanBindingSource.DataMember = "vorrunde_spielplan";
            this.vorrunde_spielplanBindingSource.DataSource = this.tables;
            // 
            // tables
            // 
            this.tables.DataSetName = "tables";
            this.tables.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vorrunde_gra_viewBindingSource
            // 
            this.vorrunde_gra_viewBindingSource.DataMember = "vorrunde_gra_view";
            this.vorrunde_gra_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grb_viewBindingSource
            // 
            this.vorrunde_grb_viewBindingSource.DataMember = "vorrunde_grb_view";
            this.vorrunde_grb_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grc_viewBindingSource
            // 
            this.vorrunde_grc_viewBindingSource.DataMember = "vorrunde_grc_view";
            this.vorrunde_grc_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grd_viewBindingSource
            // 
            this.vorrunde_grd_viewBindingSource.DataMember = "vorrunde_grd_view";
            this.vorrunde_grd_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_gre_viewBindingSource
            // 
            this.vorrunde_gre_viewBindingSource.DataMember = "vorrunde_gre_view";
            this.vorrunde_gre_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grf_viewBindingSource
            // 
            this.vorrunde_grf_viewBindingSource.DataMember = "vorrunde_grf_view";
            this.vorrunde_grf_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grg_viewBindingSource
            // 
            this.vorrunde_grg_viewBindingSource.DataMember = "vorrunde_grg_view";
            this.vorrunde_grg_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_grh_viewBindingSource
            // 
            this.vorrunde_grh_viewBindingSource.DataMember = "vorrunde_grh_view";
            this.vorrunde_grh_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_spielplanBindingSource
            // 
            this.zwischenrunde_spielplanBindingSource.DataMember = "zwischenrunde_spielplan";
            this.zwischenrunde_spielplanBindingSource.DataSource = this.tables;
            // 
            // kreuzspiele_spielplanBindingSource
            // 
            this.kreuzspiele_spielplanBindingSource.DataMember = "kreuzspiele_spielplan";
            this.kreuzspiele_spielplanBindingSource.DataSource = this.tables;
            // 
            // platzspiele_spielplanBindingSource
            // 
            this.platzspiele_spielplanBindingSource.DataMember = "platzspiele_spielplan";
            this.platzspiele_spielplanBindingSource.DataSource = this.tables;
            // 
            // platzierungen_viewBindingSource
            // 
            this.platzierungen_viewBindingSource.DataMember = "platzierungen_view";
            this.platzierungen_viewBindingSource.DataSource = this.tables;
            // 
            // vorrunde_spielplanTableAdapter
            // 
            this.vorrunde_spielplanTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_spielplanTableAdapter
            // 
            this.zwischenrunde_spielplanTableAdapter.ClearBeforeFill = true;
            // 
            // kreuzspiele_spielplanTableAdapter
            // 
            this.kreuzspiele_spielplanTableAdapter.ClearBeforeFill = true;
            // 
            // platzspiele_spielplanTableAdapter
            // 
            this.platzspiele_spielplanTableAdapter.ClearBeforeFill = true;
            // 
            // platzierungen_viewTableAdapter
            // 
            this.platzierungen_viewTableAdapter.ClearBeforeFill = true;
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageVS);
            this.tabControlMain.Controls.Add(this.tabPageVR);
            this.tabControlMain.Controls.Add(this.tabPageZS);
            this.tabControlMain.Controls.Add(this.tabPageZR);
            this.tabControlMain.Controls.Add(this.tabPageKS);
            this.tabControlMain.Controls.Add(this.tabPagePS);
            this.tabControlMain.Controls.Add(this.tabPagePR);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Location = new System.Drawing.Point(0, 0);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(782, 231);
            this.tabControlMain.TabIndex = 8;
            // 
            // tabPageVS
            // 
            this.tabPageVS.Controls.Add(this.reportViewerVS);
            this.tabPageVS.Location = new System.Drawing.Point(4, 22);
            this.tabPageVS.Name = "tabPageVS";
            this.tabPageVS.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageVS.Size = new System.Drawing.Size(774, 205);
            this.tabPageVS.TabIndex = 0;
            this.tabPageVS.Text = "Vorrunde Spielplan";
            this.tabPageVS.UseVisualStyleBackColor = true;
            // 
            // reportViewerVS
            // 
            this.reportViewerVS.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "vorrunde_spielplan";
            reportDataSource1.Value = this.vorrunde_spielplanBindingSource;
            this.reportViewerVS.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewerVS.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_vorrunde_spielplan.rdlc";
            this.reportViewerVS.Location = new System.Drawing.Point(3, 3);
            this.reportViewerVS.Name = "reportViewerVS";
            this.reportViewerVS.Size = new System.Drawing.Size(768, 199);
            this.reportViewerVS.TabIndex = 0;
            // 
            // tabPageVR
            // 
            this.tabPageVR.Controls.Add(this.reportViewerVR);
            this.tabPageVR.Location = new System.Drawing.Point(4, 22);
            this.tabPageVR.Name = "tabPageVR";
            this.tabPageVR.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageVR.Size = new System.Drawing.Size(774, 205);
            this.tabPageVR.TabIndex = 1;
            this.tabPageVR.Text = "Vorrunde Ergebnisse";
            this.tabPageVR.UseVisualStyleBackColor = true;
            // 
            // reportViewerVR
            // 
            this.reportViewerVR.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource2.Name = "vorrunde_gruppe_a";
            reportDataSource2.Value = this.vorrunde_gra_viewBindingSource;
            reportDataSource3.Name = "vorrunde_gruppe_b";
            reportDataSource3.Value = this.vorrunde_grb_viewBindingSource;
            reportDataSource4.Name = "vorrunde_gruppe_c";
            reportDataSource4.Value = this.vorrunde_grc_viewBindingSource;
            reportDataSource5.Name = "vorrunde_gruppe_d";
            reportDataSource5.Value = this.vorrunde_grd_viewBindingSource;
            reportDataSource6.Name = "vorrunde_gruppe_e";
            reportDataSource6.Value = this.vorrunde_gre_viewBindingSource;
            reportDataSource7.Name = "vorrunde_gruppe_f";
            reportDataSource7.Value = this.vorrunde_grf_viewBindingSource;
            reportDataSource8.Name = "vorrunde_gruppe_g";
            reportDataSource8.Value = this.vorrunde_grg_viewBindingSource;
            reportDataSource9.Name = "vorrunde_gruppe_h";
            reportDataSource9.Value = this.vorrunde_grh_viewBindingSource;
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource4);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource5);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource6);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource7);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource8);
            this.reportViewerVR.LocalReport.DataSources.Add(reportDataSource9);
            this.reportViewerVR.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_vorrunde.rdlc";
            this.reportViewerVR.Location = new System.Drawing.Point(3, 3);
            this.reportViewerVR.Name = "reportViewerVR";
            this.reportViewerVR.Size = new System.Drawing.Size(768, 199);
            this.reportViewerVR.TabIndex = 0;
            // 
            // tabPageZS
            // 
            this.tabPageZS.Controls.Add(this.reportViewerZS);
            this.tabPageZS.Location = new System.Drawing.Point(4, 22);
            this.tabPageZS.Name = "tabPageZS";
            this.tabPageZS.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageZS.Size = new System.Drawing.Size(774, 205);
            this.tabPageZS.TabIndex = 2;
            this.tabPageZS.Text = "Zwischenrunde Spielplan";
            this.tabPageZS.UseVisualStyleBackColor = true;
            // 
            // reportViewerZS
            // 
            this.reportViewerZS.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource10.Name = "zwischenrunde_spielplan";
            reportDataSource10.Value = this.zwischenrunde_spielplanBindingSource;
            this.reportViewerZS.LocalReport.DataSources.Add(reportDataSource10);
            this.reportViewerZS.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_zwischenrunde_spielplan.rdlc";
            this.reportViewerZS.Location = new System.Drawing.Point(3, 3);
            this.reportViewerZS.Name = "reportViewerZS";
            this.reportViewerZS.Size = new System.Drawing.Size(768, 199);
            this.reportViewerZS.TabIndex = 0;
            // 
            // tabPageZR
            // 
            this.tabPageZR.Controls.Add(this.reportViewerZR);
            this.tabPageZR.Location = new System.Drawing.Point(4, 22);
            this.tabPageZR.Name = "tabPageZR";
            this.tabPageZR.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageZR.Size = new System.Drawing.Size(774, 205);
            this.tabPageZR.TabIndex = 3;
            this.tabPageZR.Text = "Zwischenrunde Ergebnisse";
            this.tabPageZR.UseVisualStyleBackColor = true;
            // 
            // reportViewerZR
            // 
            this.reportViewerZR.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource11.Name = "zwischenrunde_gruppe_a";
            reportDataSource11.Value = this.zwischenrunde_gra_viewBindingSource;
            reportDataSource12.Name = "zwischenrunde_gruppe_b";
            reportDataSource12.Value = this.zwischenrunde_grb_viewBindingSource;
            reportDataSource13.Name = "zwischenrunde_gruppe_c";
            reportDataSource13.Value = this.zwischenrunde_grc_viewBindingSource;
            reportDataSource14.Name = "zwischenrunde_gruppe_d";
            reportDataSource14.Value = this.zwischenrunde_grd_viewBindingSource;
            reportDataSource15.Name = "zwischenrunde_gruppe_e";
            reportDataSource15.Value = this.zwischenrunde_gre_viewBindingSource;
            reportDataSource16.Name = "zwischenrunde_gruppe_f";
            reportDataSource16.Value = this.zwischenrunde_grf_viewBindingSource;
            reportDataSource17.Name = "zwischenrunde_gruppe_g";
            reportDataSource17.Value = this.zwischenrunde_grg_viewBindingSource;
            reportDataSource18.Name = "zwischenrunde_gruppe_h";
            reportDataSource18.Value = this.zwischenrunde_grh_viewBindingSource;
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource11);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource12);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource13);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource14);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource15);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource16);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource17);
            this.reportViewerZR.LocalReport.DataSources.Add(reportDataSource18);
            this.reportViewerZR.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_zwischenrunde.rdlc";
            this.reportViewerZR.Location = new System.Drawing.Point(3, 3);
            this.reportViewerZR.Name = "reportViewerZR";
            this.reportViewerZR.Size = new System.Drawing.Size(768, 199);
            this.reportViewerZR.TabIndex = 0;
            // 
            // tabPageKS
            // 
            this.tabPageKS.Controls.Add(this.reportViewerKS);
            this.tabPageKS.Location = new System.Drawing.Point(4, 22);
            this.tabPageKS.Name = "tabPageKS";
            this.tabPageKS.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageKS.Size = new System.Drawing.Size(774, 205);
            this.tabPageKS.TabIndex = 4;
            this.tabPageKS.Text = "Kreuzspiele Spielplan";
            this.tabPageKS.UseVisualStyleBackColor = true;
            // 
            // reportViewerKS
            // 
            this.reportViewerKS.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource19.Name = "kreuzspiele_spielplan";
            reportDataSource19.Value = this.kreuzspiele_spielplanBindingSource;
            this.reportViewerKS.LocalReport.DataSources.Add(reportDataSource19);
            this.reportViewerKS.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_kreuzspiele_spielplan.rdlc";
            this.reportViewerKS.Location = new System.Drawing.Point(3, 3);
            this.reportViewerKS.Name = "reportViewerKS";
            this.reportViewerKS.Size = new System.Drawing.Size(768, 199);
            this.reportViewerKS.TabIndex = 0;
            // 
            // tabPagePS
            // 
            this.tabPagePS.Controls.Add(this.reportViewerPS);
            this.tabPagePS.Location = new System.Drawing.Point(4, 22);
            this.tabPagePS.Name = "tabPagePS";
            this.tabPagePS.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePS.Size = new System.Drawing.Size(774, 205);
            this.tabPagePS.TabIndex = 5;
            this.tabPagePS.Text = "Platzspiele Spielplan";
            this.tabPagePS.UseVisualStyleBackColor = true;
            // 
            // reportViewerPS
            // 
            this.reportViewerPS.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource20.Name = "platzspiele_spielplan";
            reportDataSource20.Value = this.platzspiele_spielplanBindingSource;
            this.reportViewerPS.LocalReport.DataSources.Add(reportDataSource20);
            this.reportViewerPS.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_platzspiele_spielplan.rdlc";
            this.reportViewerPS.Location = new System.Drawing.Point(3, 3);
            this.reportViewerPS.Name = "reportViewerPS";
            this.reportViewerPS.Size = new System.Drawing.Size(768, 199);
            this.reportViewerPS.TabIndex = 0;
            // 
            // tabPagePR
            // 
            this.tabPagePR.Controls.Add(this.reportViewerPR);
            this.tabPagePR.Location = new System.Drawing.Point(4, 22);
            this.tabPagePR.Name = "tabPagePR";
            this.tabPagePR.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePR.Size = new System.Drawing.Size(774, 205);
            this.tabPagePR.TabIndex = 6;
            this.tabPagePR.Text = "Platzierungen";
            this.tabPagePR.UseVisualStyleBackColor = true;
            // 
            // reportViewerPR
            // 
            this.reportViewerPR.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource21.Name = "platzierungen_view";
            reportDataSource21.Value = this.platzierungen_viewBindingSource;
            this.reportViewerPR.LocalReport.DataSources.Add(reportDataSource21);
            this.reportViewerPR.LocalReport.ReportEmbeddedResource = "vbtournamentreporter.report_platzierung.rdlc";
            this.reportViewerPR.Location = new System.Drawing.Point(3, 3);
            this.reportViewerPR.Name = "reportViewerPR";
            this.reportViewerPR.Size = new System.Drawing.Size(768, 199);
            this.reportViewerPR.TabIndex = 0;
            // 
            // vorrunde_gra_viewTableAdapter
            // 
            this.vorrunde_gra_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grb_viewTableAdapter
            // 
            this.vorrunde_grb_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grc_viewTableAdapter
            // 
            this.vorrunde_grc_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grd_viewTableAdapter
            // 
            this.vorrunde_grd_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_gre_viewTableAdapter
            // 
            this.vorrunde_gre_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grf_viewTableAdapter
            // 
            this.vorrunde_grf_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grg_viewTableAdapter
            // 
            this.vorrunde_grg_viewTableAdapter.ClearBeforeFill = true;
            // 
            // vorrunde_grh_viewTableAdapter
            // 
            this.vorrunde_grh_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_gra_viewBindingSource
            // 
            this.zwischenrunde_gra_viewBindingSource.DataMember = "zwischenrunde_gra_view";
            this.zwischenrunde_gra_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_gra_viewTableAdapter
            // 
            this.zwischenrunde_gra_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grb_viewBindingSource
            // 
            this.zwischenrunde_grb_viewBindingSource.DataMember = "zwischenrunde_grb_view";
            this.zwischenrunde_grb_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grb_viewTableAdapter
            // 
            this.zwischenrunde_grb_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grc_viewBindingSource
            // 
            this.zwischenrunde_grc_viewBindingSource.DataMember = "zwischenrunde_grc_view";
            this.zwischenrunde_grc_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grc_viewTableAdapter
            // 
            this.zwischenrunde_grc_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grd_viewBindingSource
            // 
            this.zwischenrunde_grd_viewBindingSource.DataMember = "zwischenrunde_grd_view";
            this.zwischenrunde_grd_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grd_viewTableAdapter
            // 
            this.zwischenrunde_grd_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_gre_viewBindingSource
            // 
            this.zwischenrunde_gre_viewBindingSource.DataMember = "zwischenrunde_gre_view";
            this.zwischenrunde_gre_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_gre_viewTableAdapter
            // 
            this.zwischenrunde_gre_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grf_viewBindingSource
            // 
            this.zwischenrunde_grf_viewBindingSource.DataMember = "zwischenrunde_grf_view";
            this.zwischenrunde_grf_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grf_viewTableAdapter
            // 
            this.zwischenrunde_grf_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grg_viewBindingSource
            // 
            this.zwischenrunde_grg_viewBindingSource.DataMember = "zwischenrunde_grg_view";
            this.zwischenrunde_grg_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grg_viewTableAdapter
            // 
            this.zwischenrunde_grg_viewTableAdapter.ClearBeforeFill = true;
            // 
            // zwischenrunde_grh_viewBindingSource
            // 
            this.zwischenrunde_grh_viewBindingSource.DataMember = "zwischenrunde_grh_view";
            this.zwischenrunde_grh_viewBindingSource.DataSource = this.tables;
            // 
            // zwischenrunde_grh_viewTableAdapter
            // 
            this.zwischenrunde_grh_viewTableAdapter.ClearBeforeFill = true;
            // 
            // reporter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 231);
            this.Controls.Add(this.tabControlMain);
            this.Name = "reporter";
            this.Text = "Reporter";
            this.Load += new System.EventHandler(this.reporter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_spielplanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tables)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gra_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grb_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grc_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grd_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_gre_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grf_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grg_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vorrunde_grh_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_spielplanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kreuzspiele_spielplanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.platzspiele_spielplanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.platzierungen_viewBindingSource)).EndInit();
            this.tabControlMain.ResumeLayout(false);
            this.tabPageVS.ResumeLayout(false);
            this.tabPageVR.ResumeLayout(false);
            this.tabPageZS.ResumeLayout(false);
            this.tabPageZR.ResumeLayout(false);
            this.tabPageKS.ResumeLayout(false);
            this.tabPagePS.ResumeLayout(false);
            this.tabPagePR.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gra_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grb_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grc_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grd_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_gre_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grf_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grg_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zwischenrunde_grh_viewBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion


        private System.Windows.Forms.BindingSource vorrunde_spielplanBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_spielplanBindingSource;
        private System.Windows.Forms.BindingSource kreuzspiele_spielplanBindingSource;
        private System.Windows.Forms.BindingSource platzspiele_spielplanBindingSource;
        private System.Windows.Forms.BindingSource platzierungen_viewBindingSource;

        private tables tables;
        private tablesTableAdapters.vorrunde_spielplanTableAdapter vorrunde_spielplanTableAdapter;
        private tablesTableAdapters.zwischenrunde_spielplanTableAdapter zwischenrunde_spielplanTableAdapter;
        private tablesTableAdapters.kreuzspiele_spielplanTableAdapter kreuzspiele_spielplanTableAdapter;
        private tablesTableAdapters.platzspiele_spielplanTableAdapter platzspiele_spielplanTableAdapter;
        private tablesTableAdapters.platzierungen_viewTableAdapter platzierungen_viewTableAdapter;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageVS;
        private System.Windows.Forms.TabPage tabPageVR;
        private System.Windows.Forms.TabPage tabPageZS;
        private System.Windows.Forms.TabPage tabPageZR;
        private System.Windows.Forms.TabPage tabPageKS;
        private System.Windows.Forms.TabPage tabPagePS;
        private System.Windows.Forms.TabPage tabPagePR;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerVS;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerVR;
        private System.Windows.Forms.BindingSource vorrunde_gra_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grb_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grc_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grd_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_gre_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grf_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grg_viewBindingSource;
        private System.Windows.Forms.BindingSource vorrunde_grh_viewBindingSource;
        private tablesTableAdapters.vorrunde_gra_viewTableAdapter vorrunde_gra_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grb_viewTableAdapter vorrunde_grb_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grc_viewTableAdapter vorrunde_grc_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grd_viewTableAdapter vorrunde_grd_viewTableAdapter;
        private tablesTableAdapters.vorrunde_gre_viewTableAdapter vorrunde_gre_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grf_viewTableAdapter vorrunde_grf_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grg_viewTableAdapter vorrunde_grg_viewTableAdapter;
        private tablesTableAdapters.vorrunde_grh_viewTableAdapter vorrunde_grh_viewTableAdapter;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerZS;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerZR;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerKS;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerPS;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerPR;
        private System.Windows.Forms.BindingSource zwischenrunde_gra_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grb_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grc_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grd_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_gre_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grf_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grg_viewBindingSource;
        private System.Windows.Forms.BindingSource zwischenrunde_grh_viewBindingSource;
        private tablesTableAdapters.zwischenrunde_gra_viewTableAdapter zwischenrunde_gra_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grb_viewTableAdapter zwischenrunde_grb_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grc_viewTableAdapter zwischenrunde_grc_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grd_viewTableAdapter zwischenrunde_grd_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_gre_viewTableAdapter zwischenrunde_gre_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grf_viewTableAdapter zwischenrunde_grf_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grg_viewTableAdapter zwischenrunde_grg_viewTableAdapter;
        private tablesTableAdapters.zwischenrunde_grh_viewTableAdapter zwischenrunde_grh_viewTableAdapter;
    }
}

